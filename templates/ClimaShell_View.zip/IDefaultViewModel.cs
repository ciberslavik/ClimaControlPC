﻿using ClimaControl.UI.UICore.ViewModels;

namespace $rootnamespace$
{
    public interface $safeitemname$:IViewModel
    {
        
    }
}