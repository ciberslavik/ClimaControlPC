﻿namespace $rootnamespace$
{
    public class $safeitemname$:I$fileinputname$ViewModel
    {
        public string Title { get; set; }
    }
}