﻿using ClimaControl.UI.UICore.Views;

namespace $rootnamespace$
{
    public interface $safeitemname$:IView
    {
        
    }
}