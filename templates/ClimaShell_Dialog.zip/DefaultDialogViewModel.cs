﻿namespace $rootnamespace$
{
    public class $safeitemname$:I$fileinputname$DialogViewModel
    {
        public string Title { get; set; }
    }
}