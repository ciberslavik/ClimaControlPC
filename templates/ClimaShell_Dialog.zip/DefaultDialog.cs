﻿using ClimaControl.UI.UICore.Dialogs;
using ClimaShellDialogTemplate;

namespace $rootnamespace$
{
    public class $safeitemname$:DialogBase, I$fileinputname$Dialog
    {
        public $safeitemname$(I$fileinputname$DialogView view, I$fileinputname$DialogViewModel vm) : base(view, vm)
        {
        }
    }
}