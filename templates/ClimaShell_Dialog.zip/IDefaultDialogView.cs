﻿using ClimaControl.UI.UICore.Dialogs;

namespace $rootnamespace$
{
    public interface $safeitemname$:IDialogView
    {
        
    }
}